package com.example.quiz

import androidx.appcompat.app.AppCompatActivity


class TestActivity : AppCompatActivity() {
}